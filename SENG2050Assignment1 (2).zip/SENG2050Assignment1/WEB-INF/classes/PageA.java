import support.*;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(value = "/PageA")
public class PageA extends HttpServlet {
   public static  Post[] posts = new Post[5];
   public static Post currentpost = new Post();
    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        PrintWriter out = response.getWriter();
        out.println(GenerateHTML.fileType());
        out.println("<head>");
        out.println(GenerateHTML.Title("PageA"));
        out.println(GenerateHTML.css("myStyle.css"));
        out.println("</head>");
        out.println("<body>");
        out.println("<script type =\"text/javascript\">");
        RequestDispatcher dispatch = request.getRequestDispatcher("/WEB-INF/JavaScript.js");
        dispatch.include(request,response);
        out.println("</script>");
        out.println(GenerateHTML.Heading("Discussion Board", 1));
        if(posts[0] != null) {
            out.println("<ol>");

            for (int i = 0; posts[i] != null; i++)
            {
                currentpost = posts[i];
                String title = posts[i].getTitle();
                String author = posts[i].getAuthor();
                String time = posts[i].getTime();
                out.println(FormSupport.startPost());
                out.println("<li>");
                out.println("<form action = \"PageB\" method = \"post\">");
                out.println("<input type = \"hidden\" name = \"post\" value =\"posts[i]\">");
                out.println("<a href = \"PageB\" onclick =\"PostB(); return false;\" >");
                out.println("</form>");
                out.println(GenerateHTML.Heading(title, 3));
                out.println(GenerateHTML.P(author));
                out.println(GenerateHTML.P(time));
                out.println("</a>");
                out.println("</section>");
                out.println("</li>");
                out.println(FormSupport.endPost());
            }
            out.println("</ol>");
        }
        out.println("<div>");
        out.println(GenerateHTML.Heading("Create Post",4));
        out.println("<form name = \"easyform\" method= \"post\" onsubmit=\"return checkValid()\">");
        out.println("Name:"+"<input type=\"text\" name=\"name\"/>  <br/>");
        out.println("Message Title:"+"<input type=\"text\" name=\"title\"/>  <br/>");
        //try text area here after.
        out.println("Message:"+"<input type=\"textarea\" name=\"content\"/>  <br/>");
        out.println("<input type=\"submit\">");
        out.println("</form>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }

//  String name = request.getParameter("name");
//        out.println("<p>"+name+"</p>");
    public void doPost(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws IOException, ServletException {
        PrintWriter out = response.getWriter();
        String name, time, title, content;
        name = request.getParameter("name");
        title = request.getParameter("title");
        content = request.getParameter("content");
        DateTimeFormatter form = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        time = form.format(LocalDateTime.now());
        int index = 0;
        while (index < 5) {
        if (posts[index] == null) {
        break;
        }
        index++;
        }
        if (name == null || name == " ") {
            name = "anonymous";
        }
        if (request.getParameter("type") == null) {

            posts[index] = new Post(name, time, index, title, "fortnite");
            doGet(request, response);
            return;
        }
        return;
    }
//    public Post() currentPost()
//    {
//        return tempPost;
//
//    }


    public boolean makePost(HttpServletRequest request) {
//        PrintWriter out = response.getWriter();
//        int index = 0;
//        while(index < 5)
//        {
//            if(posts[index] == null)
//            {
//                break;
//            }
//            index++;
//        }
//        String name,time,title,content;
//        name = request.getParameter("name");
//        title = request.getParameter("title");
//        content = request.getParameter("content");
//        DateTimeFormatter form = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
//        time = form.format(LocalDateTime.now());
//        if(name == null || name == " ")
//        {
//            name = "anonymous";
//        }
//        posts[index] = new Post(name,time,index, title, "fortnite");
//        doGet(request,response);
//        return;
        return true;
    }
    public void outputPost(HttpServletResponse response) throws IOException
    {
        PrintWriter out = response.getWriter();
        return;
    }
}
//