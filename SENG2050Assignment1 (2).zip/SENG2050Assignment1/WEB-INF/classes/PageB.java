import support.*;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(value = "/PageB")
public class PageB extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //Generate the HTML Page
        PrintWriter out = response.getWriter();
        out.println(GenerateHTML.fileType());
        out.println("<head>");
        out.println(GenerateHTML.Title("PageB"));
        out.println(GenerateHTML.css("myStyle.css"));
        out.println("</head>");
        out.println("<body>");
        out.println("<script type =\"text/javascript\">");
        //Load JavaScript file
        RequestDispatcher dispatch = request.getRequestDispatcher("/WEB-INF/JavaScript.js");
        dispatch.include(request, response);
        out.println("</script>");
        out.println(GenerateHTML.Heading("Discussion Board", 1));
        out.println("<div>");
        String title, time, content;
        title = PageA.currentpost.getTitle();
        time = PageA.currentpost.getTime();
        content = PageA.currentpost.getContent();
        out.println(GenerateHTML.Heading(title, 3));
        out.println(GenerateHTML.P(time));
        out.println(GenerateHTML.P(content));
        out.println("</div>");
        out.println(GenerateHTML.Heading("Post Reply", 4));
        out.println("<form action = \"PageA\" name = \"easyform\" method= \"post\" onsubmit=\"return checkValid()\">");
        out.println("Name:" + "<input type=\"text\" name=\"name\"/>  <br/>");
        out.println("Message Title:" + "<input type=\"text\" name=\"title\"/>  <br/>");
        //try text area here after.
        out.println("Message:" + "<input type=\"text\" name=\"content\"/>  <br/>");
        //  Put Back in if the null checker doesnt work.
        out.println("<input type = \"hidden\" name = \"type\" value = \"true\")
        out.println("<input type=\"submit\">");
        out.println("</form>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }

    public void doPost(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws IOException, ServletException {
        PrintWriter out = response.getWriter();
        //Generate the HTML Page
        out.println(GenerateHTML.fileType());
        out.println("<head>");
        out.println(GenerateHTML.Title("PageB"));
        out.println(GenerateHTML.css("myStyle.css"));
        out.println("</head>");
        out.println("<body>");
        out.println("<script type =\"text/javascript\">");
        //Load JavaScript file
        RequestDispatcher dispatch = request.getRequestDispatcher("/WEB-INF/JavaScript.js");
        dispatch.include(request, response);
        out.println("</script>");
        out.println(GenerateHTML.Heading("Discussion Board", 1));
        out.println("<div>");
        String title, time, content;
        title = PageA.currentpost.getTitle();
        time = PageA.currentpost.getTime();
        content = PageA.currentpost.getContent();
        out.println(GenerateHTML.Heading(title, 3));
        out.println(GenerateHTML.P(time));
        out.println(GenerateHTML.P(content));
        out.println("</div>");
        out.println(GenerateHTML.Heading("Post Reply", 4));
        out.println("<form action = \"PageA\" name = \"easyform\" method= \"post\" onsubmit=\"return checkValid()\">");
        out.println("Name:" + "<input type=\"text\" name=\"name\"/>  <br/>");
        out.println("Message Title:" + "<input type=\"text\" name=\"title\"/>  <br/>");
        //try text area here after.
        out.println("Message:" + "<input type=\"text\" name=\"content\"/>  <br/>");
    //  Put Back in if the null checker doesnt work.
        //    out.println("<input type = \"hidden\" name = \"type\" value = \"true\")
        out.println("<input type=\"submit\">");
        out.println("</form>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}

//    PrintWriter out = response.getWriter();
//    String name,time,title,content;
//        name = request.getParameter("name");
//                title = request.getParameter("title");
//                content = request.getParameter("content");
//                DateTimeFormatter form = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
//                time = form.format(LocalDateTime.now());
//                if(name == null || name == " ")
//                {
//                name = "anonymous";
//                }
//
//                return;
//doPost(request,response);
//        PrintWriter out = response.getWriter();
//        out.println(GenerateHTML.fileType());
//        out.println("<head>");
//        out.println(GenerateHTML.Title("PageB"));
//        out.println(GenerateHTML.css("myStyle.css"));
//        out.println("</head>");
//        out.println("<body>");
//        out.println("<script type =\"text/javascript\">");
//        RequestDispatcher dispatch = request.getRequestDispatcher("/WEB-INF/JavaScript.js");
//        dispatch.include(request, response);
//        out.println("</script>");
//        out.println(GenerateHTML.Heading("Discussion Board", 1));
//
//        out.println("<div>");
//        if (PageA.posts[0] != null) {
//            out.println("<p>fortnite</p>");
//        }
//        out.println(GenerateHTML.Heading("Post Reply", 4));
//        out.println("<form action = \"PageA\" name = \"easyform\" method= \"post\" onsubmit=\"return checkValid()\">");
//        out.println("Name:" + "<input type=\"text\" name=\"name\"/>  <br/>");
//        out.println("Message Title:" + "<input type=\"text\" name=\"title\"/>  <br/>");
//        //try text area here after.
//        out.println("Message:" + "<input type=\"text\" name=\"content\"/>  <br/>");
//        out.println("<input type=\"submit\">");
//        out.println("</form>");
//        out.println("</div>");
//        out.println("</body>");
//        out.println("</html>");