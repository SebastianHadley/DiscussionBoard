package support;

public class GenerateHTML
{
    //Used to output DOCTYPE.
    public static String fileType()
    {
        return "<!DOCTYPE HTML>";
    }
    //Used to generate a title for a html page.
    public static String Title(String title)
    {
        return "<title>" + title + "</title>";
    }

    public static String Meta()
    {
        return "<meta charset = \"UTF-8\">";
    }
    public static String Heading(String output, int x)
    {
        return "<h" + x + ">" + output + "</h" + x + ">";
    }

    public static String openBody()
    {
        return "<body>";
    }

    public static String closeBody()

    {
        return "</body>";
    }
    public static String css(String file)
    {
        return " <link rel=\"stylesheet\" type=\"text/css\" href="+file+">";
    }

    public static String script(String href)
    {
        return "<script src=\"" + href + "\"></script>";
    }

    public static String P(String text)
    {
        return "<p>" + text + "</p>";
    }
}