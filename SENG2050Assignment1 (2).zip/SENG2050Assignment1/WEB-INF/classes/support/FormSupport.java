package support;

public class FormSupport
{
    private static int posts = 0;
    public static String startPost()
    {
        return "<div class = \"post\">";
    }
    public static String endPost()
    {
        return "</div>";
    }
    public static synchronized void upPosts()
    {
        posts++;
        return;
    }
    public static synchronized int getPosts()
    {
        return posts;
    }
}