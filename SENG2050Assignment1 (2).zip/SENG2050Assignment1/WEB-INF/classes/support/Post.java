package support;

public class Post{
    private int postnumber;
    private String author;
    private String time;
    private String title;
    private String content;
    private Post reply;
    private boolean isReply;
    public Post()
    {}
    public Post(String author, String time, int number, String title, String content) {
        postnumber = number;
        this.author = author;
        this.time = time;
        this.title = title;
        this.content = content;
        this.isReply = false;
    }

    public void Reply(String author,String time,String title,String content)
    {
        Post reply = new Post(author,time,0,title,content);
    }
    public Post getReply()
    {
        return reply;
    }
    public boolean getReplies(int replies,String pass)
    {
        replies++;
        if(reply != null) {
            reply.getReplies(replies,pass);
        }
        if(replies == 10)
        {
            pass = "fail";
        }
        if(pass == "fail")
        {
            return false;
        }
        else
            return true;
    }
//    public boolean checkReplies(int layer)
//    {
//
//        if(layer == 9)
//        {
//            return false;
//        }
//        layer++;
//        if(reply.checkReplies(layer) == false)
//        {
//            return false;
//        }
//        else
//            return true;
//
////        if(int i = 0; i < 10; i++)
////        {
////            if(i == 9) {
////                if (getReply().reply != null) {
////                    return false;
////                }
////            }
////            reply.checkReplies;
////        }
////        return true;
//    }

//Getters
    public String getAuthor()
    {
        return author;
    }
    public String getTime()
    {
        return time;
    }
    public String getContent()
    {
        return content;
    }
    public boolean isReply()
    {
        return isReply;
    }
    public int getNumber()
    {
        return postnumber;
    }
    public String getTitle()
    {
        return title;
    }
}