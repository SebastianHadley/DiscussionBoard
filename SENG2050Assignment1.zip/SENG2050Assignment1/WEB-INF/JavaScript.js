inclu
function checkValid()
{

        var title = document.forms.easyform.elements.title.value;
        var content = document.forms.easyform.elements.content.value;
        var failMessage = "Input has the following errors:\n";
        var valid = true;
        if(title == "" || title == null)
        {
            valid = false;
            failMessage+="Title cannot be blank\n";
        }
        if(content.length > 50 || content.length < 5 )
        {
           valid = false;
           failMessage+="Message must be between 5 and 50 characters\n";
        }
        if(valid == false)
        {
         alert(failMessage);
         return false;
        }
        return true;
}
function postB()
{   alert("fortnite");
    document.forms.replying.submit();


}

